import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * Main functionality of the PFE graphing tool.
 * 
 * @author Muhammad Khattak 
 */
public class Main
{
    private JFrame frame;
    private JFrame graph;
    private JPanel panel;
    private JButton butt;
    private JTextField field;
    private Dimension screenSize;
    private int height;
    private int width;
    private double[] y;
    private int xinit = -30;
    private String function;
    private Image img;
    
    public Main()
    {
        screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        height = (int)screenSize.getHeight();
        width = (int)screenSize.getWidth();
        y = new double[60];
        
        field = new JTextField("");
        field.setPreferredSize(new Dimension(100, 30));
        panel = new JPanel(new FlowLayout());
        panel.setPreferredSize(new Dimension(width, height));
        butt = new JButton("Enter");
        butt.setPreferredSize(new Dimension(40,40));
        butt.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent ev)
                {
                    function = field.getText();
                    for (int x = 0; x < y.length; x++)
                    {
                        y[x] = doMath(function, xinit);
                        xinit++;
                    }
                    graph = new JFrame("Graph");
                    img = new Image(y, height, width);
                    img.setPreferredSize(new Dimension(width, height));
                    graph.add(img);
                    graph.setContentPane(img);
            		graph.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            		graph.setSize(width, height);
            		frame.setVisible(false);
            		frame.dispose();
            		graph.pack();
            		graph.setVisible(true);
                }
            });
        
        panel.add(field);
        panel.add(butt);
        
        frame = new JFrame("PFE Graph Tool");
        frame.add(panel);
        frame.setContentPane(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(width, height);
		frame.pack();
		frame.setVisible(true);
    }

    public int[] findX(String str)
    {
        int[] xind = new int[50];
        int count = 0;
        for (int x = 0; x < str.length(); x++)
        {
            if (str.charAt(x) == 'x')
            {
                xind[count] = x;
                count++;
            }
        }
        
        int[] actual = new int[count];
        for (int x = 0; x < actual.length; x++)
        {
            actual[x] = xind[x];
        }
        
        return actual;
    }
    
    public double doMath(String str, double xvalue)
    {
        String temp = str.replaceAll(" ", "");
        int[] xind = findX(temp);
        int count = 0;
        double sum = 0;
       
        for (int x = 0; x < temp.length(); x++)
        {
            if (temp.charAt(x) == '^')
            {
                try
                {
                    if (temp.charAt(x-1) == 'x')
                    {
                        sum += Math.pow(xvalue, ((double)(temp.charAt(x+1) - '0')));
                    } else if (temp.charAt(x+1) == 'x')
                    {
                        sum += Math.pow((double)(temp.charAt(x-1) - '0'), xvalue);
                    } else
                    {
                        sum += Math.pow((double)(temp.charAt(x-1) - '0'), (double)(temp.charAt(x+1) - '0'));
                    }
                }catch (IndexOutOfBoundsException e){}
            } else if (temp.charAt(x) == '/')
            {
                try
                {
                    if (temp.charAt(x-1) == 'x')
                    {
                        sum += (xvalue / (double)(temp.charAt(x+1) - '0'));
                    } else if (temp.charAt(x+1) == 'x')
                    {
                        sum += ((double)(temp.charAt(x-1) - '0') / xvalue);
                    } else
                    {
                        sum += ((double)(temp.charAt(x-1) - '0') / (double)(temp.charAt(x+1) - '0'));
                    }
                }catch (IndexOutOfBoundsException e){}
            } else if (temp.charAt(x) == '*')
            {
                try
                {
                    if (temp.charAt(x-1) == 'x')
                    {
                        sum += (xvalue * (double)(temp.charAt(x+1) - '0'));
                    } else if (temp.charAt(x+1) == 'x')
                    {
                        sum += ((double)(temp.charAt(x-1) - '0') * xvalue);
                    } else
                    {
                        sum += ((double)(temp.charAt(x-1) - '0') * (double)(temp.charAt(x+1) - '0'));;
                    }
                }catch (IndexOutOfBoundsException e){}
            } else if (temp.charAt(x) == '+')
            {
                try
                {
                    if (temp.charAt(x-1) == 'x')
                    {
                        sum += (xvalue + (double)(temp.charAt(x+1) - '0'));
                    } else if (temp.charAt(x+1) == 'x')
                    {
                        sum += ((double)(temp.charAt(x-1) - '0') + xvalue);
                    } else
                    {
                        sum += ((double)(temp.charAt(x-1) - '0') + (double)(temp.charAt(x+1) - '0'));;
                    }
                }catch (IndexOutOfBoundsException e){}
            } else if (temp.charAt(x) == '-')
            {
                try
                {
                    if (temp.charAt(x-1) == 'x')
                    {
                        sum += (xvalue - (double)(temp.charAt(x+1) - '0'));
                    } else if (temp.charAt(x+1) == 'x')
                    {
                        sum += ((double)(temp.charAt(x-1) - '0') - xvalue);
                    } else
                    {
                        sum += ((double)(temp.charAt(x-1) - '0') - ((double)(temp.charAt(x+1) - '0')));;
                    }
                }catch (IndexOutOfBoundsException e){}
                
                sum = 0;
            }
        }
        
        return sum;
    }

    public static void main(String[] args)
    {
        Main main = new Main();
    }
}
