import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Image extends JPanel
{
    private double y[];
    private int ht;
    private int wt;
    
    public Image(double[] y, int height, int width)
    {
        this.y = y;
        ht = height;
        wt = width;
    }
    
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        this.setBackground(Color.WHITE);
        g.setColor(Color.BLACK);
        int init = 0;
        
        g.drawLine(0, 1080/2, 1920, 1080/2);
        g.drawLine(1920/2, 0, 1920/2, 1080);
        
        for (int a = 0; a < y.length; a++)
        {
            g.fillOval(init + ((1920/y.length) * a),((1080 / 2) - (int)y[a]), 5, 5);
        }
    }
}